﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using Windows.Networking.Sockets;
using Windows.Storage.Streams;

namespace SimpleWeb
{
    class Server
    {
        private StreamSocketListener listener;
        private const uint BufferSize = 8192;
        public Server()
        {
        }
        public void Initialise()
        {
            listener = new StreamSocketListener();

#pragma warning disable CS4014
            listener.BindServiceNameAsync("80");
#pragma warning restore CS4014

            listener.ConnectionReceived += (s, e) => ProcessRequestAsync(e.Socket);
        }

        private async void ProcessRequestAsync(StreamSocket socket)
        {
            StringBuilder request = new StringBuilder();

            using (IInputStream input = socket.InputStream)
            {
                byte[] data = new byte[BufferSize];
                IBuffer buffer = data.AsBuffer();
                uint dataRead = BufferSize;
                while (dataRead == BufferSize)
                {
                    await input.ReadAsync(buffer, BufferSize, InputStreamOptions.Partial);
                    request.Append(Encoding.UTF8.GetString(data, 0, data.Length));
                    dataRead = buffer.Length;
                }
            }
            // Send a response back
            using (IOutputStream output = socket.OutputStream)
            {
                string requestMethod = request.ToString().Split('\n')[0];
                string[] requestParts = requestMethod.Split(' ');

                if (requestParts[0] == "GET")
                    await WriteResponseAsync(requestParts[1], output);
                else
                    throw new InvalidDataException("HTTP method not supported: "
                                                   + requestParts[0]);
                
            }
        }

        private async Task WriteResponseAsync(string v, IOutputStream output)
        {
            ParseInput(v);

            using (Stream response = output.AsStreamForWrite())
            {
                string defaultPage = File.ReadAllText("webpages\\mainpage.html");
                // For now we are just going to reply to anything with Hello World!
                byte[] bodyArray = Encoding.UTF8.GetBytes(defaultPage);

                var bodyStream = new MemoryStream(bodyArray);

                // This is a standard HTTP header so the client browser knows the bytes returned are a valid http response
                var header = "HTTP/1.1 200 OK\r\n" +
                            $"Content-Length: {bodyStream.Length}\r\n" +
                                "Connection: close\r\n\r\n";

                byte[] headerArray = Encoding.UTF8.GetBytes(header);

                // send the header with the body inclded to the client
                await response.WriteAsync(headerArray, 0, headerArray.Length);
                await bodyStream.CopyToAsync(response);
                await response.FlushAsync();
            }
        }

        private void ParseInput(string v)
        {
            string[] splitString = v.Split('?');

            switch(splitString[0])
            {
                case "/index.html":
                    ParseIndexWebpage(splitString[1]);
                    break;
                default: break;
            }
        }

        private void ParseIndexWebpage(string v)
        {
            string[] commands = v.Split('&');
            foreach( var item in commands)
            {
                ParseCommand(item);
            }
        }

        private void ParseCommand(string item)
        {
            string[] data = item.Split('=');
            switch (data[0])
            {
                case "revolution":
                    break;
                default: break;
            }
        }
    }
}
